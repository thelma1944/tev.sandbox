########
Support
########

You can get support and discuss about new features on:
https://groups.google.com/d/forum/python-mysql-replication

You can browse and report issues on:
https://github.com/noplay/python-mysql-replication/issues
