###################
Events
###################

.. automodule:: pymysqlreplication.event
    :members:

==========
Row events
==========

This events are send by MySQL when data are modified.

.. automodule:: pymysqlreplication.row_event
    :members:
